<?php
include('vendor/inc/config.php');

if (isset($_GET['u_id'])) {
    $u_id = $_GET['u_id'];
    $sql = "DELETE FROM tms_user WHERE u_id = '$u_id'";
    $result = mysqli_query($mysqli, $sql);

    if ($result) {
        echo "<script>alert('Deleted')</script>";
        echo "<script>window.location='admin-manage-user.php'</script>"; 
    } else {
        echo "<script>alert('Unsuccessful, Please Try Again Later')</script>";
        echo "<script>window.location='admin-manage-user.php'</script>"; 
    }
} else {
    echo "<script>alert('Invalid or Missing u_id parameter')</script>";
    echo "<script>window.location='admin-manage-user.php'</script>"; 
}
?>
